import { Component, OnInit } from '@angular/core';
import { BookdaoService } from '../bookdao.service';
import { Book } from '../model/book';

@Component({
  selector: 'app-searchbook',
  templateUrl: './searchbook.component.html',
  styleUrls: ['./searchbook.component.css']
})
export class SearchbookComponent implements OnInit {
  book: Book;
  bookIdValue: any;
  bookNameValue: any;
  bookdao: BookdaoService;
  result: String;

  constructor(bookdao: BookdaoService) {
    this.book = new Book(0, '', '');
    this.bookdao = bookdao;
    this.result = '';
    this.bookIdValue = undefined;
    this.bookNameValue = undefined;
  }
  ngOnInit(): void {
  }

  searchBookById(form: any) {
    this.getBookById(this.bookIdValue);
  }

  searchBookByName(form: any) {
    this.getBookByName(this.bookNameValue);
  }

  getBookById(id: Number) {
    this.bookdao.getBookById(id).subscribe(
      (data: Book) => {
        console.log(data);
        this.book = data;
        this.result = 'Book found successfully';
      }, (error) => {
        console.log(error);
        this.result = 'Book not found';
      }
    )
  }

  getBookByName(name: String) {
    this.bookdao.getBookByName(name).subscribe(
      (data: Book) => {
        this.book = data;
        this.result = 'Book found successfully';
      }, (error) => {
        console.log(error);
        this.result = 'Book not found';
      }
    )
  }
}
