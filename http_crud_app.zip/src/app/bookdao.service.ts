import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { Book } from './model/book';

@Injectable({
  providedIn: 'root'
})
export class BookdaoService {

  baseUrl: string;
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(private httpClient: HttpClient) {

    this.baseUrl = 'http://localhost:8081';
  }

  getBookById(bookId: Number) {
    return this.httpClient.get<Book>(this.baseUrl + `/book1/${bookId}`, this.httpOptions).pipe(
      catchError(this.errorHandler)
    );
  }
  
  getBookByName(bookName: String) {
    return this.httpClient.get<Book>(this.baseUrl + `/bookName/${bookName}`, this.httpOptions).pipe(
      catchError(this.errorHandler)
    );
  }

  addBook(b: Book) {
    return this.httpClient.post<Book>(this.baseUrl + '/addBook1', JSON.stringify(b), this.httpOptions).pipe(
      catchError(this.errorHandler)
    );
  }

  getAllBooks() {
    return this.httpClient.get<Book[]>(this.baseUrl + '/allBooks', this.httpOptions).pipe(
      catchError(this.errorHandler)
    );
  }

  deleteBook(bookId: number) {
    return this.httpClient.delete<Boolean>(this.baseUrl + `/removeBook1/${bookId}`).pipe(catchError(this.errorHandler));
  }

  updateBook(bookId: Number, b: Book) {
    return this.httpClient.put<Boolean>(this.baseUrl + `/updateBook/${bookId}`, JSON.stringify(b), this.httpOptions).pipe(
      catchError(this.errorHandler)
    );
  }

  errorHandler(httpError: HttpErrorResponse) {
    let errorMessage = '';
    if (httpError.error instanceof ErrorEvent) {
      errorMessage = httpError.error.message;
    } else {
      errorMessage = `Error Code: ${httpError.status}\nMessage: ${httpError.message}`;
    }
    console.log(errorMessage);
    return throwError(() => httpError);
  }
}
