import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookformComponent } from './bookform/bookform.component';
import { BooklistComponent } from './booklist/booklist.component';
import { SearchbookComponent } from './searchbook/searchbook.component';
import { UpdatebookComponent } from './updatebook/updatebook.component';

const routes: Routes = [
  {
    path: 'addBook',
    component: BookformComponent
  }, {
    path: '',
    redirectTo: 'addBook',
    pathMatch: 'full'
  }, {
    path: 'listBooks',
    component: BooklistComponent
  }, {
    path: 'searchBook',
    component: SearchbookComponent
  }, {
    path: 'updateBook',
    component: UpdatebookComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
