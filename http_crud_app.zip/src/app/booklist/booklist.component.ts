import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BookdaoService } from '../bookdao.service';
import { Book } from '../model/book';

@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BooklistComponent implements OnInit {

  bookarr: Book[];
  bookdao: BookdaoService;

  constructor(private router: Router, bookdao: BookdaoService) {
    this.bookarr = [];
    this.bookdao = bookdao;
  }

  ngOnInit(): void {
    this.bookdao.getAllBooks().subscribe(
      (data: Book[]) => {
        console.log(data);
        this.bookarr = data;
      }
    );
  }

  updateBook(id: number) {
    console.log(`edit called ${id}`);
    this.router.navigate(['/updateBook'], {queryParams: {bookId: id}});
  }

  deleteBook(id: number) {
    console.log('delete called');
    this.bookdao.deleteBook(id).subscribe(() => this.ngOnInit());
  }

}
